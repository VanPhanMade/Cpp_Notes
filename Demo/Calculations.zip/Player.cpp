#include "Player.h"
#include <iostream>

Player::Player(PlayerType _playerType)
{
	playerType = playerType;
}

Player::Player()
{
	Accounts = 21;
}
