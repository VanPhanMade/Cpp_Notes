#include "Calculations.h"

int Add(int a, int b, int c) {
	return a + b + c;
}