#pragma once

void Log(const char* message);
