#pragma once
class VariablesAndDataTypes
{
	public: 
		VariablesAndDataTypes();
	 
	protected: 
	 
	private:

		
};

