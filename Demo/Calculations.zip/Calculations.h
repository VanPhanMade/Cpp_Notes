#pragma once

int Add(int a, int b, int c);