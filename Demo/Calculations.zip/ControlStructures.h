#pragma once
class ControlStructures
{
	public: 
		ControlStructures();
	protected: 
	 
	private:
};

