#pragma once
class Operators
{
	public: 
		Operators();

	protected: 
		 
	private:
		
};

